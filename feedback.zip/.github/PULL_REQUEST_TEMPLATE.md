## 🔍 Checklist voor Inlevering

Controleer voordat je indient:
- [ ] Alle HTML bestanden zijn gevalideerd
- [ ] CSS bestand is gekoppeld en werkt
- [ ] Menu werkt op alle pagina's
- [ ] Code is netjes ingesprongen
- [ ] Geen inline styles gebruikt

## 💭 Reflectie
Wat ging goed? Waar liep je tegenaan? Wat ga je volgende keer anders doen?